<?php

include 'functions.php';
echo availabledocsproperty() //functions.php

?>
