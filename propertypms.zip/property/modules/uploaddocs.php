<?php
include 'functions.php';
echo uploaddocs();