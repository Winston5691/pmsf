<?php
include 'functions.php';
echo getlegdocuments($_REQUEST['propid']);
echo getpropdocuments($_REQUEST['propid']);