<?php
include 'functions.php';

// SMTP and client details
$smtpConfig = [
    'host' => 'smtp-host',
    'username' => 'your-smtp-username',
    'password' => 'your-smtp-password',
    'port' => 587,
    'encryption' => 'tls',
];

// Define predefined client details
$clientDetails = [
    [
        'name' => 'Client Name 1',
        'email' => 'client1@example.com',
    ]
];

// API endpoint for retrieving holiday dates
$holidayApiEndpoint = 'https://holidayapi.com/v1/holidays?country=KE&year=2023';

$holidays = retrieveHolidayDates($holidayApiEndpoint);

// Process predefined client details and send holiday greetings
foreach ($clientDetails as $client) {
    $name = htmlspecialchars($client['name']);
    $email = htmlspecialchars($client['email']);
    $address = 'Client Address'; // Define or retrieve the client's address

    // Sending holiday greetings with the retrieved holiday dates
    echo sendHolidayGreetings($smtpConfig, $name, $email, $address, $holidays);
}

function retrieveHolidayDates($apiEndpoint) {
    $apiResponse = file_get_contents($apiEndpoint);
    $holidayData = json_decode($apiResponse, true);

    // Extract holiday dates from the response
    $holidays = [];
    if (isset($holidayData['holidays'])) {
        foreach ($holidayData['holidays'] as $holiday) {
            $holidays[] = [
                'name' => $holiday['name'],
                'date' => $holiday['date'],
            ];
        }
    }

    return $holidays;
}

function sendHolidayGreetings($smtpConfig, $name, $email, $address, $holidays) {
    $mail = new PHPMailer(true);
    $mail->isHTML(true);
    $mail->Subject = 'Holiday Greetings';
    $mail->Body = "Wishing you a joyful holiday, $name!<br><br>";
    $mail->Body .= "Upcoming holidays:<br>";
    foreach ($holidays as $holiday) {
        $mail->Body .= "- " . $holiday['name'] . " on " . $holiday['date'] . "<br>";
    }
    if ($mail->send()) {
        return "Email sent successfully to $email.";
    } else {
        return "Email sending failed to $email.";
    }
}
?>
