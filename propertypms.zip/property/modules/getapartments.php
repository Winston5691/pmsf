<?php
include 'functions.php';
echo vacant_apartments($_REQUEST['propid']);
?>
