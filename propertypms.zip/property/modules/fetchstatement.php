<?php
include('functions.php');
echo fetchstatement(6,31);

