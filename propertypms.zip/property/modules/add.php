<?php
      include 'functions.php';
       addproperty1();