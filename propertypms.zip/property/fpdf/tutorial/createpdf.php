<?php

//ini_set('display_errors',1);
//ini_set('display_startup_errors',1);
//error_reporting(-1);
require('../fpdf.php');
include_once '../../includes/database.php';
include '../../includes/numberformatter.php'; //format amount in words
include  '../../modules/functions.php';

class PDF extends FPDF
{
// Load dat

}

$document=$_REQUEST['document'];
$propid=$_REQUEST['propid'];
$user=$_REQUEST['username'];

if($document=='invoice'){
 printthisinvoice($_REQUEST['invoiceno'], $propid, $user);//$pdf->LoadData('countries.txt');
}

if($document=='receipt'){
 printthisreceipt($_REQUEST['recpno'],$propid, $user);//$pdf->LoadData('countries.txt');
}


function printthisinvoice($invoiceno, $propid, $user) {
    $pdf = new PDF();
// Column headings
// Data loading
$pdf->SetFont('Arial','',12);
$pdf->AddPage('L','A5');

      $db = new MySQLDatabase();
    date_default_timezone_set('Africa/Nairobi');
    $date = date("d/m/y");
    $time = date('h:i A');
    $db->open_connection();
    $tablename = "invoices";
    $tablename1 = "chargeitems";
    $tablename2 = "invoiceitems";
    $tableitems = [];
    $chargeablesamount=array();
    $chargeableitems=array();
    $sql =$db->query("SELECT * FROM $tablename WHERE `invoiceno` like '$invoiceno'") or die($db->error());
    if ($db->num_rows($sql) > 0) {
        while ($row = $db->fetch_array($sql)) {
            $invoiceno = $row['invoiceno'];
            $invoicedate = $row['invoicedate'];
            $amount = $row['amount'];
            $idno = $row['idno'];
            $incomeacct = $row['incomeaccount'];
            $billing = $row['invoicecredit'];
            $remarks = $row['remarks'];
        }
        //get apartment No
        $apartmentid=getApartmentFromTenant($idno);
        $aptdetails=  getApartmentDetails($apartmentid);
        $billing == 0 ? $value ="INVOICE" : $value ="CREDIT NOTE"; //type of billing
        $sql1 = $db->query("SELECT accname FROM $tablename1 WHERE `id` like '$incomeacct' ORDER BY `priority` ASC") or die($db->error());
        while ($row1 = $db->fetch_array($sql1)) {
            $accname = $row1['accname'];
        }
        $sql2 = $db->query("SELECT tenants.property_name,tenants.apartmentid,tenants.Id,tenants.tenant_name,floorplan.last_water_reading,floorplan.current_water_reading FROM tenants  JOIN floorplan ON tenants.apartmentid=floorplan.apt_id WHERE ( tenants.Id='$idno' AND tenants.vacated like '0')") or die($db->error());
        while ($row2 = $db->fetch_array($sql2)) {
            $propertyname = $row2['property_name'];
            $tname = $row2['tenant_name'];
            $tenantid=$row['Id'];
            $lastwater = $row2['last_water_reading'];
            $currentwater = $row2['current_water_reading'];
        }
        //get sum of chargeable items
        $sql3 = $db->query("SELECT item_name,amount FROM $tablename2 WHERE invoiceno='$invoiceno' ORDER BY priority ASC") or die($db->error());
        while ($row3 = $db->fetch_array($sql3)) {
            $item_name = $row3['item_name'];
            $item_amount = $row3['amount'];
            //total amount
            array_push($chargeablesamount,$item_amount);
            array_push($chargeableitems,$item_name);
            //if the charge item !=0
            if($item_amount !=0){
            array_push($tableitems, ' '. $item_name . '   KES: ' . number_format($item_amount, 2));
            }
        }
        //get outstanding balance/prepayment
        $balance=  getCorrectBalance($idno,$invoiceno);
        $chargestotal=array_sum($chargeablesamount);
        $totaldue=$balance+$chargestotal;
        //page width
        $pagewidth=140;
        $pdf->SetX(9);
      
      //logo
       $pdf->Image('../../images/cursors/anjuman.png',$pagewidth+30,2,25,20,'','http://www.petaagency.com');
       $pdf->Ln();
       
       //invoiceno
        $pdf->SetX(9);
        $pdf->SetY(25);
 $pdf->SetFont('Arial','',11);
    $pdf->SetFillColor(245,245,220);
    $pdf->SetDrawColor(217,74,56);
    $pdf->SetLineWidth(1);
   $pdf->Cell(45,8,$value.' NO '.$invoiceno,1,1,'C',true);
   //invoice date
   $pdf->SetY(30);
   $pdf->SetX($pagewidth-20);
           $pdf->Cell(20,0,'Date: '.date("d-m-Y",strtotime($invoicedate)));
       $pdf->Ln(5);
       //$pdf->SetDrawColor(217,74,56);
    $pdf->SetFont('Arial','B',10);
   $pdf->Cell(45,10,'NAME:'.ucwords(@$tname).'('.$aptdetails[0]['apt_tag'].')');
   $pdf->Ln(5);
   $pdf->Cell(45,10,'PROPERTY:'.ucwords(str_replace('_', " ", @$propertyname)));
   
    $pdf->SetY(40);
   $pdf->SetX(120);
           $pdf->Cell(20,0,'CHARGEABLES AMOUNT: Ksh ' . number_format($chargestotal,2) );
     $pdf->SetY(45);
   $pdf->SetX(120);
           $pdf->Cell(20,0,'TOTAL AMOUNT DUE: Ksh '.number_format($totaldue,2));
           $pdf->SetFont('Arial','I',10);
            $pdf->SetY(50);
   $pdf->SetX(5);
           $pdf->SetDrawColor(217,74,56);
      $pdf->Cell(200,2,  str_repeat('-',$pagewidth));
      //chargeables
      $pdf->SetX(6);
      $pdf->Ln(1);
      $pdf->SetFont('Arial','I',8);
   $pdf->Cell(45,10,'B.B.F: KES '.number_format($balance,2));
   $pdf->Ln(1);
   foreach ($chargeableitems as $value) {
    if (strtoupper($value) == 'WATER') {
                $pdf->Ln(3);
                $pdf->Cell(105,10,'Last Reading: ' . $lastwater . ' Current Reading:  ' . $currentwater . ' Consumption: ' . ($currentwater - $lastwater) . 'units Rate:(ksh)' . get_water_rate($propid));
                          }
                          }
   foreach ($tableitems as $key => $value1) {
           
            $pdf->Ln(5);
             $pdf->Cell(45,10,trim($key[0]).trim($value1,0));
           
        }
          $pdf->Ln(8);
   $pdf->Cell(100,10,'Being '.strtolower($value).' for '.$remarks );
   $pdf->Ln(8);
        $pdf->SetDrawColor(217,74,56);
      $pdf->Cell(200,2,  str_repeat('-',$pagewidth));
     $pdf->Ln(1);
     $pdf->SetFont('Arial','I',9);
   $pdf->Cell(100,10,'All acounts are due on or before the 5th day of the month,failure to settle by the said date attracts a penalty of 10%');
   $pdf->Ln(4);
     $pdf->Cell(100,10,$user . ' ' . $date . ' ' . $time );
  
   $tenantdetails=getTenantDetails($idno) ;
$pdf->SetX($pagewidth-10);
  $pdf->Cell(100,10,$tenantdetails['email']);
   
    } else {
        return false;
    }
       //save and email
$emails=getAdminEmail();
    $to =$tenantdetails['email'];
$from =$emails['from'];
$cc =$emails['cc'];
$subject = "PETA AGENCY Rent Invoice ".date("d-m-Y",strtotime($invoicedate));
$message = "<p>Please find document attached."
        . "</p>";
// a random hash will be necessary to send mixed content
$separator = md5(time());
// carriage return type (we use a PHP end of line constant)
$eol = PHP_EOL;
// attachment name
$filename = $invoiceno.".pdf";
// encode data (puts attachment in proper format)
$pdfdoc = $pdf->Output("", "S");
$attachment = chunk_split(base64_encode($pdfdoc));
// main header (multipart mandatory)


$headers = "From: ".$from.$eol;
$headers="CC: ".$cc.$eol;
        $headers .= "MIME-Version: 1.0".$eol;
$headers .= "Content-Type: multipart/mixed; boundary=\"".$separator."\"".$eol.$eol;
$headers .= "Content-Transfer-Encoding: 7bit".$eol;
$headers .= "This is a MIME encoded message.".$eol.$eol;
// message
$headers .= "--".$separator.$eol;
$headers .= "Content-Type: text/html; charset=\utf-8\"".$eol;
$headers.= "X-Priority: 1\r\n"; 
$headers .= "Content-Transfer-Encoding: 8bit".$eol.$eol;
$headers .= $message.$eol.$eol;
// attachment
$headers .= "--".$separator.$eol;
$headers .= "Content-Type: application/octet-stream; name=\"".$filename."\"".$eol;
$headers .= "Content-Transfer-Encoding: base64".$eol;
$headers .= "Content-Disposition: attachment".$eol.$eol;
$headers .= $attachment.$eol.$eol;
$headers .= "--".$separator."--";
// send message
if(mail($to, $subject, "", $headers)){
    echo 'Successfully sent email to&nbsp;'.$to.'<a href="../../modules/defaultreports.php?report=printinvoice&invoiceno='.$_REQUEST['invoiceno'].'">&nbsp;Back To Invoice</a>';
}
 else {
echo 'failed to send email';    
}
}

function printthisreceipt($receiptno, $propid, $user) {
    $pdf = new PDF();
// Column headings
// Data loading
$pdf->SetFont('Arial','',12);
$pdf->AddPage('L','A5');

    $db = new MySQLDatabase();
    date_default_timezone_set('Africa/Nairobi');
    $date = date("d/m/y");
    $time = date('h:i A');
    $db->open_connection();
    $tablename = "recptrans";
    $tablename2 = "tenants";
    $tablename3 = "invoiceitems";
    $invoicetable=  getInvoiceTable();
    $tableitems = [];
    $chargeablesamount=array();
    
    $sql = $db->query("SELECT * FROM $tablename WHERE `recpno` like '$receiptno'") or die($db->error());
    if ($db->num_rows($sql) > 0) {
        while ($row = $db->fetch_array($sql)) {
            $recpno = $row['recpno'];
            $recpdate = $row['rdate'];
            $amount = $row['amount'];
            $idno = $row['idno'];
            $remarks = $row['rmks'];
            $invoiceno = $row['invoicenopaid'];
        }
        $sql2 = $db->query("SELECT property_name,tenant_name,Apartment_tag FROM $tablename2 WHERE ( `Id`='$idno' AND `vacated` like '0')") or die($db->error());
        while ($row2 =$db->fetch_array($sql2)) {
            $propertyname = $row2['property_name'];
            $tname = $row2['tenant_name'];
            $tag = $row2['Apartment_tag'];
        }
        $sql3 =$db->query("SELECT item_name,amount FROM $tablename3 WHERE invoiceno='$invoiceno' ORDER BY `priority` ASC") or die($db->error());
        while ($row3 = $db->fetch_array($sql3)) {
            $item_name = $row3['item_name'];
            $item_amount = $row3['amount'];
            array_push($chargeablesamount,$item_amount);
            array_push($tableitems, $item_name . ': Ksh:' . number_format($item_amount, 2));
        }

//tenant enail
   $tenantdetails=getTenantDetails($idno) ;

         //get outstanding balance/prepayment
        
        $balance=  getCorrectBalance($idno,$latestinvoice='0');
        
        $penaltysql=$db->query("SELECT amount FROM $invoicetable WHERE recpno='$recpno' AND `is_penalty`=1 ") or die($db->error());
        while ($row= $db->fetch_array($penaltysql)) {
            $penaltyamount = $row['amount'];
              }
        //page width
        $pagewidth=140;
        $pdf->SetX(9);
      
      //logo
       $pdf->Image('../../images/cursors/anjuman.png',$pagewidth+30,2,25,20,'','http://www.petaagency.com');
       $pdf->Ln();
       
       //invoiceno
        $pdf->SetX(9);
        $pdf->SetY(25);
 $pdf->SetFont('Arial','',11);
    $pdf->SetFillColor(245,245,220);
    $pdf->SetDrawColor(217,74,56);
    $pdf->SetLineWidth(1);
   $pdf->Cell(45,8,'RECEIPT NO ' . $recpno,1,1,'C',true);
   //invoice date
   $pdf->SetY(30);
   $pdf->SetX($pagewidth-10);
           $pdf->Cell(20,0,'Date: '.date("d-m-Y",strtotime($recpdate)));
       $pdf->Ln(5);
       //$pdf->SetDrawColor(217,74,56);
    $pdf->SetFont('Arial','B',10);
   $pdf->Cell(45,10,'NAME:'.ucwords($tname).'  '.ucwords(str_replace('_', " ", @$propertyname)) . ' (' . @$tag . ')');
   $pdf->Ln(5);
   $pdf->Cell(45,10,'Received: The sum of Kshs ' . convert_number_to_words($amount) . ' only.');
   $pdf->Ln(5);
   $pdf->Cell(45,10,'Being payment for:' . $remarks );
   
    $pdf->SetY(40);
   $pdf->SetX($pagewidth-10);
           $pdf->Cell(20,0,'AMOUNT: Ksh ' . number_format($amount, 2) );
      
           $pdf->SetFont('Arial','I',10);
            $pdf->SetY(55);
   $pdf->SetX(5);
          // $pdf->SetDrawColor(217,74,56);
      $pdf->Cell(200,2,  str_repeat('-',$pagewidth));
      //chargeables
         $pdf->Ln(1);
 
   foreach ($tableitems as $key => $value1) {
           
            $pdf->Ln(5);
             $pdf->Cell(45,10,trim($key[0]).trim($value1,0));
           
        }
          $pdf->Ln(8);
       
   if($balance){
           $pdf->SetX(6);
      $pdf->Ln(1);
      $pdf->SetFont('Arial','I',8);
   $pdf->Cell(45,10,'B.C.F: KES '.number_format($balance,2));
        }
   $pdf->Ln(8);
        $pdf->SetDrawColor(217,74,56);
      $pdf->Cell(200,2,  str_repeat('-',$pagewidth));
        $pdf->Ln(4);
     $pdf->Cell(100,10,$user . ' ' . $date . ' ' . $time );
$pdf->SetX($pagewidth-10);
  $pdf->Cell(100,10,$tenantdetails['email']);
   
    } else {
        return false;
    }

        //save and email
$emails=getAdminEmail();
    $to =$tenantdetails['email'];
    $from =$emails['from'];
     $cc =$emails['cc'];
$subject = "PETA AGENCY RECEIPT ".date("d-m-Y",strtotime($recpdate));
$message = "<p>Please find document attached."
        . "</p>";
// a random hash will be necessary to send mixed content
$separator = md5(time());
// carriage return type (we use a PHP end of line constant)
$eol = PHP_EOL;
// attachment name
$filename = $receiptno.".pdf";
// encode data (puts attachment in proper format)
$pdfdoc = $pdf->Output("", "S");
$attachment = chunk_split(base64_encode($pdfdoc));
// main header (multipart mandatory)


$headers = "From: ".$from.$eol;
$headers="CC: ".$cc.$eol;
$headers .= "MIME-Version: 1.0".$eol;
$headers .= "Content-Type: multipart/mixed; boundary=\"".$separator."\"".$eol.$eol;
$headers .= "Content-Transfer-Encoding: 7bit".$eol;
$headers .= "This is a MIME encoded message.".$eol.$eol;
// message
$headers .= "--".$separator.$eol;
$headers .= "Content-Type: text/html; charset=\utf-8\"".$eol;
$headers.= "X-Priority: 1\r\n"; 
$headers .= "Content-Transfer-Encoding: 8bit".$eol.$eol;
$headers .= $message.$eol.$eol;
// attachment
$headers .= "--".$separator.$eol;
$headers .= "Content-Type: application/octet-stream; name=\"".$filename."\"".$eol;
$headers .= "Content-Transfer-Encoding: base64".$eol;
$headers .= "Content-Disposition: attachment".$eol.$eol;
$headers .= $attachment.$eol.$eol;
$headers .= "--".$separator."--";
// send message
if(mail($to, $subject, "", $headers)){
    echo 'Successfully sent email to&nbsp;'.$to.'<a href="../../modules/defaultreports.php?report=printreceipt&receiptno='.$receiptno.'">&nbsp;Back To Receipt</a>';
}
 else {
echo 'failed to send email';    
}

}




